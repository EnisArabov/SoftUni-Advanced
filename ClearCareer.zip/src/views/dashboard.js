import { html } from "../../node_modules/lit-html/lit-html.js";
import { getAllOffers } from "../api/data.js";
import { offerPreview } from "./common.js";

let dashboardTemplate = (offers) => html`
  <section id="dashboard">
    <h2>Job Offers</h2>
    ${offers.length == 0
      ? html`<h2>No offers yet.</h2>`
      : html`${offers.map(offerPreview)}`}
  </section>
`;


export async function dashboardPage(ctx){
    let offers = await getAllOffers()
    ctx.render(dashboardTemplate(offers))
}
