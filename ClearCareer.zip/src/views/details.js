import { html } from "../../node_modules/lit-html/lit-html.js";
import {
  deleteOffer,
  getMyAppByOfferId,
  getOfferById,
  getTotalAppCount,
  requestToAddAnApplication,
} from "../api/data.js";
import { getUserData } from "../util.js";

let detailsTemplate = (
  offer,
  isOwner,
  onDelete,
  applications,
  showApplyButton,
  onApply
) => html`
  <section id="details">
    <div id="details-wrapper">
      <img id="details-img" src=${offer.imageUrl} alt="example1" />
      <p id="details-title">${offer.title}</p>
      <p id="details-category">
        Category: <span id="categories">${offer.category}</span>
      </p>
      <p id="details-salary">
        Salary: <span id="salary-number">${offer.salary}</span>
      </p>
      <div id="info-wrapper">
        <div id="details-description">
          <h4>Description</h4>
          <span>${offer.description}</span>
        </div>
        <div id="details-requirements">
          <h4>Requirements</h4>
          <span>${offer.requirements}</span>
        </div>
      </div>
      <p>Applications: <strong id="applications">${applications}</strong></p>

     ${offerControlsTemplates(offer,isOwner,onDelete)}
     ${applyControlTemplate(showApplyButton,onApply)}
      </div>
    </div>
  </section>
`;

let offerControlsTemplates = (offer, isOwner, onDelete) => {
  if (isOwner) {
    return html`
      <a href="/edit/${offer._id}" id="edit-btn">Edit</a>
      <a @click=${onDelete} href="javascript:void(0)" id="delete-btn">Delete</a>
    `;
  } else {
    return null;
  }
};

let applyControlTemplate = (showApplyButton, onApply) => {
  if (showApplyButton) {
    return html`
      <a @click=${onApply} href="javascript:void(0)" id="apply-btn">Apply</a>
    `;
  } else {
    return null;
  }
};

export async function detailsPage(ctx) {
  let userData = getUserData();

  let [offer, apply, hasApply] = await Promise.all([
    getOfferById(ctx.params.id),
    getTotalAppCount(ctx.params.id),
    userData ? getMyAppByOfferId(ctx.params.id, userData.id) : 0,
  ]);

  let isOwner = userData && userData.id == offer._ownerId;
  let showApplyButton =
    isOwner == false && hasApply == false && userData != null;
  ctx.render(
    detailsTemplate(offer, isOwner, onDelete, apply, showApplyButton, onApply)
  );

  async function onDelete() {
    await deleteOffer(ctx.params.id);
    ctx.page.redirect("/dashboard");
  }

  async function onApply() {
    await requestToAddAnApplication(ctx.params.id);
    ctx.page.redirect("/details/" + ctx.params.id);
  }
}
